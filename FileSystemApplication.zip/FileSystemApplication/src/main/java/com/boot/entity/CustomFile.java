
package com.boot.entity;

import java.io.File;
import java.io.Serializable;
import java.util.Date;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.web.multipart.MultipartFile;

@XmlRootElement
public class CustomFile implements Serializable {
	
	
	private static final long serialVersionUID = -1L;
	
	private int id;
	private String fileName;
	private String savedBy;
	private MultipartFile file;
	private Date savedDate;
	@XmlAttribute
	public int getId() {
		return id;
	}
	@Generated("id")
	public void setId(int id) {
		this.id = id;
	}
	@XmlElement
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@XmlElement
	public String getSavedBy() {
		return savedBy;
	}
	public void setSavedBy(String savedBy) {
		this.savedBy = savedBy;
	}
	public MultipartFile getFile() {
		return file;
	}
	@XmlElement
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public Date getSavedDate() {
		return savedDate;
	}
	@XmlElement
	public void setSavedDate(Date savedDate) {
		this.savedDate = savedDate;
	}
	public CustomFile[] listFiles() {
		// TODO Auto-generated method stub
		return null;
	}
	
	 
	
}
