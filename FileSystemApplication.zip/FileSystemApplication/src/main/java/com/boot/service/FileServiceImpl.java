package com.boot.service;

import java.io.File;
import java.security.Principal;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.boot.dao.FileServiceDao;
import com.boot.entity.CustomFile;

@Service
public class FileServiceImpl implements FilesService{

	
@Autowired 
FileServiceDao fileServiceDao;
	public CustomFile getMetadata(int fileID) {
		// TODO Auto-generated method stub
		return fileServiceDao.getMetadata(fileID);
	}

	public File getContent(String fileID) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<File> getFilesList(String searchCriteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public void sendEmail() {
		// TODO Auto-generated method stub
		
	}

	public void upload(MultipartFile file, Principal principal) {
		fileServiceDao.save(file, principal);
		
	}
	
}