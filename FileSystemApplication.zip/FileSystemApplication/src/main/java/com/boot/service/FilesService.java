package com.boot.service;

import java.io.File;
import java.security.Principal;
import java.util.ArrayList;

import org.springframework.web.multipart.MultipartFile;

import com.boot.entity.CustomFile;

public interface FilesService {
	public void upload(MultipartFile file, Principal principal);
	public CustomFile getMetadata(int fileID);
	public File getContent(String fileID);
	public ArrayList<File> getFilesList (String searchCriteria);
	public void sendEmail();

}
