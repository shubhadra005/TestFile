package com.boot.dao;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;


import java.util.Date;

import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.boot.entity.CustomFile;


@Repository
public class FileServiceDaoImpl implements FileServiceDao {
	private static final String UPLOAD_FOLDER = "C://files/";
	public void save(MultipartFile file, Principal principal) {
		try {
			
			CustomFile fileToBeSaved = new CustomFile();
			fileToBeSaved.setId(1);
			fileToBeSaved.setFileName(file.getName());
			fileToBeSaved.setFile(file);
			fileToBeSaved.setSavedBy(principal.getName());
			fileToBeSaved.setSavedDate(new Date());
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(out);
			os.writeObject(fileToBeSaved);
				    
            byte[] bytes = out.toByteArray();
            Path path = Paths.get(UPLOAD_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);
           
} catch(Exception e){
			
			e.getStackTrace();
		}
		
	}
	public CustomFile getMetadata(int fileID) {
		//needs to be implemented
		return null;
	}
	
	
}
