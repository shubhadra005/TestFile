package com.boot.dao;

import java.security.Principal;

import org.springframework.web.multipart.MultipartFile;

import com.boot.entity.CustomFile;

public interface FileServiceDao {
public void save(MultipartFile file, Principal principal);

public CustomFile getMetadata(int fileID);
}
