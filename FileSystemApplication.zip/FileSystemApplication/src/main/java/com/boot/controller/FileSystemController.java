package com.boot.controller;

import java.io.File;
import java.security.Principal;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.boot.entity.CustomFile;
import com.boot.entity.Person;
import com.boot.service.FilesService;

@RestController
public class FileSystemController {
	
	@Autowired
	FilesService fileService;
//	@GetMapping(value = "/", produces={"application/xml"})
//	public @ResponseBody ArrayList<Person> listOfUsers(){
//		ArrayList<Person> a = new ArrayList<Person>();
//				Person p1 = new Person();
//				p1.setFirstName("Shubhadra");
//				p1.setLastName("Bhandari");
//			 a.add(p1);
//			return a;
//			}
	
	
	@GetMapping(value ="/")
	public String getPage(){
		return "upload";
	}
	// File Upload Api
	
	@PostMapping("/upload")
	public ResponseEntity<Object> upload(@RequestParam("file") MultipartFile file,Principal principal, RedirectAttributes redirectAttributes, HttpServletRequest req) {
		boolean fileSaved = false;
		if (file.isEmpty()){
			redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
           
		}
		fileService.upload(file,principal);
		fileSaved = true;
		if (fileSaved) {
			
			return new ResponseEntity<Object>(HttpStatus.OK);	
		}
		return null;
		
	}
	@RequestMapping(value = "/getMetadata",produces={"application/xml"})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody CustomFile getMetadata(int fileID) {
		
		return fileService.getMetadata(fileID);
		}
	
	@RequestMapping("/getContent")
	public File getContent(String fileID) {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping("/getFiles")
	public ArrayList<File> getFilesList(String searchCriteria) {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping("/chron")
	public void sendEmail() {
		// TODO Auto-generated method stub
		
	}
}
